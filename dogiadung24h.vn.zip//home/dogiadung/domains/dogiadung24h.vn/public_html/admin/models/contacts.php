<?php
class Contacts extends AppModel {
    var $name = 'Contacts';
   
}
?>
