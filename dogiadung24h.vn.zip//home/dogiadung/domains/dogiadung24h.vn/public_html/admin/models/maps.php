<?php
class Maps extends AppModel {
    var $name = 'Map';
    var $displayField = 'name';
   	var $validate = array(
		'id' => array(
			'notempty' => array(
				'rule' => array('notempty'),
			),
		),
		
		'images' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Xin vui lòng điển thông tin',
				'allowEmpty' => false,
				'required' => false,
			),
		),
	);
	
}
?>
