<?php
class Setting extends AppModel {
    var $name = 'Setting';
   
}
?>
