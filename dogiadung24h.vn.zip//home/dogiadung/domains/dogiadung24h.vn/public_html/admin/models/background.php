<?php
class Background extends AppModel {
    var $name = 'Background';
}
?>
