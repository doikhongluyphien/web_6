<?php
class Help extends AppModel {
    var $name = 'Help';
}
?>
