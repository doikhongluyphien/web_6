<?php
class Video extends AppModel {
    var $name = 'Video';

}
?>
