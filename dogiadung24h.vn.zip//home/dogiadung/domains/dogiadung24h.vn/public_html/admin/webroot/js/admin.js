function confirmDelete(delUrl)
{
	if (confirm('Bạn có muốn xóa thật không?')==true) 
	{
		if (confirm('Tất cả các dữ liệu con của nó cũng sẽ bị xóa. Bạn có muốn thao tác tiếp')==true)
		{
			document.location = delUrl;
		}
	}
}

function get_alias(){
 var str = (document.getElementById("idtitle").value);
 str= str.toLowerCase();
 str= str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,"a");
 str= str.replace(/ệ|è|é|ẹ|ẻ|ẽ|ê|ề|ế|ể|ễ/g,"e");
 str= str.replace(/ì|í|ị|ỉ|ĩ/g,"i");
 str= str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g,"o");
 str= str.replace(/ự|ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ử|ữ/g,"u");
 str= str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y");
 str= str.replace(/đ/g,"d");
 str= str.replace(/!|@|\$|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\'| |\"|\&|\#|\[|\]|~/g,"-");
 str= str.replace(/-+-/g,"-");
 str= str.replace(/^\-+|\-+$/g,"");
 document.getElementById("idalias").value = str;
 return str;
}

function BrowseServer()
{
	var finder = new CKFinder();
	finder.basePath = 'ckfinder/';	// The path for the installation of CKFinder (default = "/ckfinder/").
	finder.selectActionFunction = SetFileField;
	finder.popup();
}

function SetFileField( fileUrl )
{
	document.getElementById( 'xFilePath' ).value = fileUrl;
}

function BrowseServer1()
{
	var finder = new CKFinder();
	finder.basePath = 'ckfinder/';	// The path for the installation of CKFinder (default = "/ckfinder/").
	finder.selectActionFunction = SetFileField1;
	finder.popup();
}

function SetFileField1( fileUrl1 )
{
	document.getElementById( 'xFilePath1' ).value = fileUrl1;
}
function BrowseServer2()
{
	var finder = new CKFinder();
	finder.basePath = 'ckfinder/';	// The path for the installation of CKFinder (default = "/ckfinder/").
	finder.selectActionFunction = SetFileField2;
	finder.popup();
}

function SetFileField2( fileUrl2 )
{
	document.getElementById( 'xFilePath2' ).value = fileUrl2;
}
function BrowseServer3()
{
	var finder = new CKFinder();
	finder.basePath = 'ckfinder/';	// The path for the installation of CKFinder (default = "/ckfinder/").
	finder.selectActionFunction = SetFileField3;
	finder.popup();
}

function SetFileField3( fileUrl3 )
{
	document.getElementById( 'xFilePath3' ).value = fileUrl3;
}