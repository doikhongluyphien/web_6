<?php
class Bgmenu extends AppModel {
    var $name = 'Bgmenu';
}
?>
