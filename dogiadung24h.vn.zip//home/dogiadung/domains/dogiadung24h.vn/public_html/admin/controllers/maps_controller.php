<?php
class MapsController extends AppController {

	var $name = 'Maps';
	function index() {
		  $this->account();		
	      $this->set('Maps', $this->Maps->read(null,1));
	}
	function add(){
		$this->account();
		if (!empty($this->data)) {
			$this->Maps->create();
			$data['Maps'] = $this->data['Maps'];
			if ($this->Maps->save($data['Maps'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mới danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
	function edit($id = 1) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$data['Maps'] = $this->data['Maps'];
			if ($this->Maps->save($data['Maps'])) {
				$this->Session->setFlash(__('Bài viết sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Bài viết này không sửa được vui lòng thử lại.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Maps->read(null, $id);
		}
		
		$this->set('edit',$this->Maps->findById($id));
	}

	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
