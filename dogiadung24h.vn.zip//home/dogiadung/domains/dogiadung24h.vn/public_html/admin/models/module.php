<?php
class Module extends AppModel {
    var $name = 'Module';
}
?>
