<?php
class PricesController extends AppController {

	var $name = 'Prices';
	function index() {
		  $this->account();
		  $this->paginate = array('conditions'=>array('Price.type'=>1),'limit' => '15','order' => 'Price.id DESC');
	      $this->set('price', $this->paginate('Price',array()));
	}
	function add(){
		$this->account();
		if (!empty($this->data)) {
			$this->Price->create();
			$data['Price'] = $this->data['Price'];
			$data['Price']['type'] = 1;
			if ($this->Price->save($data['Price'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
	function edit($id = null) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$data['Price'] = $this->data['Price'];
			if ($this->Price->save($data['Price'])) {
				$this->Session->setFlash(__('Bài viết sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Bài viết này không sửa được vui lòng thử lại.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Price->read(null, $id);
		}
		
		$this->set('edit',$this->Price->findById($id));
	}
	function delete($id = null) {
		$this->account();		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại hình ảnh này', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Price->delete($id)) {
			$this->Session->setFlash(__('Xóa  thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	
	
	function indexpower() {
		  $this->account();
		  $this->paginate = array('conditions'=>array('Price.type'=>2),'limit' => '15','order' => 'Price.id DESC');
	      $this->set('price', $this->paginate('Price',array()));
	}
	function addpower(){
		$this->account();
		if (!empty($this->data)) {
			$this->Price->create();
			$data['Price'] = $this->data['Price'];
			$data['Price']['type'] = 2;
			if ($this->Price->save($data['Price'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'indexpower'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
	function editpower($id = null) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'indexpower'));
		}
		if (!empty($this->data)) {
			$data['Price'] = $this->data['Price'];
			if ($this->Price->save($data['Price'])) {
				$this->Session->setFlash(__('Bài viết sửa thành công', true));
				$this->redirect(array('action' => 'indexpower'));
			} else {
				$this->Session->setFlash(__('Bài viết này không sửa được vui lòng thử lại.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Price->read(null, $id);
		}
		
		$this->set('edit',$this->Price->findById($id));
	}
	function deletepower($id = null) {
		$this->account();		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại hình ảnh này', true));
			$this->redirect(array('action'=>'indexpower'));
		}
		if ($this->Price->delete($id)) {
			$this->Session->setFlash(__('Xóa  thành công', true));
			$this->redirect(array('action'=>'indexpower'));
		}
		$this->Session->setFlash(__('Không xóa được', true));
		$this->redirect(array('action' => 'indexpower'));
	}

	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
