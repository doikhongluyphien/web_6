<?php
class PowersController extends AppController {

	var $name = 'Powers';
	function index(){
		$this->account();
		$this->paginate=array('limit'=>'15','order'=>'Power.id DESC');
		$this->set('Powers',$this->paginate('Power',array()));
		$list_cat = $this->Power->generatetreelist(null,null,null," _ ");
	   $this->set(compact('list_cat'));
	}

	function add() {
		$this->account();
		if (!empty($this->data)) {
			$this->Power->create();
			$data['Power'] = $this->data['Power'];
			if ($this->Power->save($data['Power'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		$this->loadModel("Power");
        $powerlist = $this->Power->generatetreelist(null,null,null," _ ");
        $this->set(compact('powerlist'));
	}
	//close tin tuc
	function close($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Power'] = $this->data['Powers'];
		$data['Power']['status']=0;
		if ($this->Power->save($data['Power'])) {
			$this->Session->setFlash(__('Bài viết không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bài viết không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	// active tin bai viêt
	function active($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Power'] = $this->data['Power'];
		$data['Power']['status']=1;
		if ($this->Power->save($data['Power'])) {
			$this->Session->setFlash(__('Bài viết được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bài viết không hiển được bài viết', true));
		$this->redirect(array('action' => 'index'));
	}
	//check ton tai tai khoan
	function delete($id = null) {	
		$this->account();	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Power->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function edit($id = null) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$data['Power'] = $this->data['Power'];			
			if ($this->Power->save($data['Power'])) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Power->read(null, $id);
			$this->set('edit',$this->Power->read(null, $id));
		}
		$this->set('list_cat',$this->_find_list());
        $this->set('edit',$this->Power->findById($id));
	}
	
	
		function _find_list() {
		return $this->Power->generatetreelist(null, null, null, '__');
	}
	
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>